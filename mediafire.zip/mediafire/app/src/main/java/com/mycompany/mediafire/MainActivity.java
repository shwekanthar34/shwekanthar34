package com.mycompany.mediafire;

import android.app.*;
import android.os.*;
import android.util.*;
import android.widget.*;
import java.io.*;
import org.jsoup.*;
import org.jsoup.nodes.*;
import org.jsoup.select.*;
import java.util.regex.*;
import org.json.*;
import android.media.*;
import android.net.*;

public class MainActivity extends Activity 
{
	TextView tv;
	MediaPlayer mp;


	//String link="http://www.mediafire.com/file/ylm04t8ib044mgh/rock-licks-one.mp3/file";
	//String link="https://www.mediafire.com/file/nj1eccpmvhh6z9q/BTTH_Book_%252870_-76%2529.pdf/file";
	//String link="https://www.mediafire.com/download/k1n0f0d907nebcx";
	String link="https://www.mediafire.com/download/473wkhgmqvcf5qg";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		tv = findViewById(R.id.tv);

		new WebScrapeTask().execute(link);

    }

	public class WebScrapeTask extends AsyncTask<String,Void,String>
	{
		@Override
		protected String doInBackground(String[] p1)
		{
			try
			{
				Document doc = Jsoup.connect(p1[0]).get();
				return process(doc);
			}
			catch (IOException e)
			{
				e.printStackTrace();
				return "";
			}
		}

		@Override
		protected void onPostExecute(final String result)
		{
			super.onPostExecute(result);

			Toast.makeText(getApplicationContext(),result,1).show();
			tv.setText(result);
		}
	}

	public String process(Document doc){
		Elements atags=doc.select("a[aria-label=Download file]");
		if(atags!=null){
			return atags.first().attr("href");


		}
		return null;
	}
}
